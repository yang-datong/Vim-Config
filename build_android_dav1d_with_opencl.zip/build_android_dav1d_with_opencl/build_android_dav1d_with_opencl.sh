#!/bin/bash
ScriptVersion="1.0"

pip="pip3"
work_path="$HOME"
current_path="`pwd`"

unset file
unset directory

main(){
	check_pip meson
	check_pip ninja

	pushd $work_path
	if [ ! -d "dav1d-master" ];then
		git clone https://github.com/videolan/dav1d.git dav1d-master
	fi

	cd dav1d-master

	cp -r ${current_path}/CL ./include/CL

	if [ -d "build" ];then
		local date=$(date +"%Y%m%d%H%M%S")
		mv build /tmp/build_${date}
	fi
	mkdir build && cd build

	local path=($(ls ${HOME}/Library/Android/sdk/ndk/))
	export NDK="${HOME}/Library/Android/sdk/ndk/${path[0]}"
	echo -e "🌟\033[31m 检测ndk-build 版本,将使用${NDK}进行编译\033[0m"
	read -p "whether continue[Y/n]" ok
	if [ "$ok" == "n" ];then
		popd
		exit
	fi

	local config_file="android_armv8.txt"

	echo "[binaries]" > $config_file
	echo "c = '${NDK}/toolchains/llvm/prebuilt/darwin-x86_64/bin/aarch64-linux-android21-clang'" >> $config_file
	echo "cpp = '${NDK}/toolchains/llvm/prebuilt/darwin-x86_64/bin/aarch64-linux-android21-clang++'" >> $config_file
	echo "ar = '${NDK}/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-ar'" >> $config_file
	echo "strip = '${NDK}/toolchains/llvm/prebuilt/darwin-x86_64/bin/llvm-strip'" >> $config_file
	echo "pkgconfig = 'pkg-config'" >> $config_file
	echo "" >> $config_file
	echo "[properties]" >> $config_file
	echo "needs_exe_wrapper = true" >> $config_file
	echo "" >> $config_file
	echo "[host_machine]" >> $config_file
	echo "system = 'android'" >> $config_file
	echo "cpu_family = 'aarch64'" >> $config_file
	echo "endian = 'little'" >> $config_file
	echo "cpu = 'aarch64'" >> $config_file

	cp ../tools/dav1d.c ../tools/dav1d.c.bck

	cp ${current_path}/dav1d.c ../tools/dav1d.c

	meson --cross-file=${config_file} --default-library=static .. && ninja -j16

	adb push ./tools/dav1d /sdcard/

	cmd "cd /data/local/tmp && mv /sdcard/dav1d ./ && chmod +x /data/local/tmp/dav1d"
	popd

	echo -e "\033[31m执行成功dav1d已放置到/data/local/tmp/dav1d \033[0m"
}

cmd(){
	adb shell "$1" || {
		echo -e "\033[31madb [ $1 ] execution faild\033[0m" ; exit
	}
}

check_pip(){
	local name="$1"
	$pip show $name
	if [ "$?" == "1" ];then
		$pip install $name
	fi
}


usage (){
  echo "Usage :  $(basename "$0") [options] [--] argument-1 argument-2

  Options:
  -h, --help                  Display this message
  -d, --debug                 Debug model run
  -p, --posix                 Posix model parse shell command
  -v, --version               Display script version
  -f, --file FILE             Target file 
  -D, --directory DIRECTORY   Target directory"

}

while getopts ":hdpvf:D:-:" opt; do
  case "${opt}" in
    h) usage && exit 0;;
    d) set -x ;;
    p) set -o posix ;;
    v) echo "$0 -- Version $ScriptVersion"; exit ;;
    f) file=${OPTARG};;
    D) directory=${OPTARG};;
    -) case "${OPTARG}" in
         help) usage && exit 0;;
         debug)      set -x ;;
         posix)      set -o posix ;;
         version)    echo "$0 -- Version $ScriptVersion"; exit ;;
         file)       file=${!OPTIND}; OPTIND=$((OPTIND+1));;
         directory)  directory=${!OPTIND}; OPTIND=$((OPTIND+1));;
         *)          echo "Invalid option: --${OPTARG}" >&2 && exit 1;;
       esac;;
    :) echo "Option -${OPTARG} requires an argument." >&2 && exit 1;;
    *) echo "Invalid option: -${OPTARG}" >&2 && exit 1;;
  esac
done
shift $((OPTIND-1))

main "$@"
